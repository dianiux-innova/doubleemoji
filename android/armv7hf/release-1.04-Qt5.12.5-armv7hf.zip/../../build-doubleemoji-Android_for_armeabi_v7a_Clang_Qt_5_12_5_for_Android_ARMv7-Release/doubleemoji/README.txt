LGPL V3 Rights:
You can rebuild this app, but you must use the same Qt version.
Please, open project in Qt creator an build your own mobile app


